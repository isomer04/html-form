public class ClassToDoList extends ToDoList {
    private String title; // don't do this - this is redundant
    // because it's inherited from the super class
}
