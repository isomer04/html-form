public class Pokemon {
}
